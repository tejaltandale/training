public class DataTypeArray{
	
	
	
	public static void main(String args[]){
		int arr []= new int[5];
		double arr2[] =new double[5];
		short arr3 []= new short[5];
		long arr4 []= new long[5];
		float arr5 []= new float[5];
		char arr6 []= new char[5];
		byte arr7 []= new byte[5];
		boolean arr8 []= new boolean[5];
		
		
		
		
		for(int i=0;i< arr.length;i++){
			System.out.println(arr[i]);
		}
		for(int i=0;i< arr2.length;i++){
			System.out.println(arr2[i]);
		}
		for(int i=0;i< arr3.length;i++){
			System.out.println(arr3[i]);
		}
		for(int i=0;i< arr4.length;i++){
			System.out.println(arr4[i]);
		}
		for(int i=0;i< arr5.length;i++){
			System.out.println(arr5[i]);
		}
		for(int i=0;i< arr6.length;i++){
			System.out.println(arr6[i]);
		}
		for(int i=0;i< arr7.length;i++){
			System.out.println(arr7[i]);
		}
		for(int i=0;i< arr8.length;i++){
			System.out.println(arr8[i]);
		}
	}

}