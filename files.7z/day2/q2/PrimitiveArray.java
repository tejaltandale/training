public class PrimitiveArray{
	
	
	
	public static void main(String args[]){
		int arr[] ={23,123,124,11,344};
		double arr2[] ={12.3,55.12,66,9,12.0,3.9};
		short arr3 []= {23,34,11,22,44};
		long arr4 []= {12L,122L,223L,144,444L};
		float arr5 []= {3f,13f,234f,12f,66f};
		char arr6 []= {'a','d','s','g','h'};
		byte arr7 []= {23,31,11,22,44};
		boolean arr8 []= {true,false,true,false,true};
		
		
		
		
		for(int i=0;i< arr.length;i++){
			System.out.println(arr[i]);
		}
		for(int i=0;i< arr2.length;i++){
			System.out.println(arr2[i]);
		}
		for(int i=0;i< arr3.length;i++){
			System.out.println(arr3[i]);
		}
		for(int i=0;i< arr4.length;i++){
			System.out.println(arr4[i]);
		}
		for(int i=0;i< arr5.length;i++){
			System.out.println(arr5[i]);
		}
		for(int i=0;i< arr6.length;i++){
			System.out.println(arr6[i]);
		}
		for(int i=0;i< arr7.length;i++){
			System.out.println(arr7[i]);
		}
		for(int i=0;i< arr8.length;i++){
			System.out.println(arr8[i]);
		}
	}

	}

