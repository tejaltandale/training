public class Actor {
		String name;
		byte age;
		
		public String toString(){
			return "Name "+name+" found";
		}
}

 