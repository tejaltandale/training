public class Services{
	Repository r = new Repository();
	
	public String createActor(Actor a){
		
				if(a.name!=null){
					r.save(a);
					return "Saved Successfully!!!";
					
				}
		
				else {
					return "Name cannot be null";
								
			    }
	}
	
	Actor searchByName(String name){
		//Repository r = new Repository();
		Actor a= r.findByName(name);
		return a;
		
	}
}