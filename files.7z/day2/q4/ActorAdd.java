public class ActorAdd {
	public static void main(String args[]){
		Actor arr[]= new Actor [5];
		arr[0] = new Actor("Leonardo",40);
		arr[1] = new Actor("Johny",42);
		arr[2] = new Actor("Matt",40);
		arr[3] = new Actor("Mathew",69);
		arr[4] = new Actor("Morgan",77);
							
							
		for(int i=0; i<arr.length;i++){
			 System.out.println("Name: "+arr[i].name+"\n Age: "+arr[i].age);
	       }
		
	}
}