public class Datatype{
	static int a = 29;
	static byte b = 29;
	static char c = 'a';
	static double d= 29.99;
	static float f = 29f;
	static short s = 29;
	static long l = 29L;
	static boolean e = true;
	
	public static void main(String args[]){
		System.out.println("Byte: "+b+"\n char: "+c+"\n short: "+s+"\n int: "+a+"\n long: "+l+"\n float: "+f+"\n double: "+d+"\n boolean: "+e);
	
	}
 	

}