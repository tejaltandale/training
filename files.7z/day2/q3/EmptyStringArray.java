public class EmptyStringArray{
	
	public static void main(String args[]){
		String str[]= new String[5];
		for(int i=0; i<str.length;i++){
			System.out.println(str[i]);
		}
	}

}