public class StringArray{
	
	public static void main(String args[]){
		String str[]= {"hello","hola","adios","namaskar","hi"};
		
		for(int i=0; i<str.length;i++){
			System.out.println(str[i]);
		}
	}

}