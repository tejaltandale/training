public class ActorClient{
	
	
	
	public static void main(String args[]){
		Services ser = new Services();
		
		Actor a1 = new Actor();
		a1.name = "leonardo";
		a1.age = 45;
		String s1 = ser.createActor(a1);
		System.out.println(""+a1.name+" "+a1.age);
		System.out.println(s1);
		
		Actor a2 = new Actor();
		a2.name = "johnny";
		a2.age = 46;
		String s2 = ser.createActor(a2);
		System.out.println(""+a2.name+" "+a2.age);
		System.out.println(s2);
		
		Actor a3 = new Actor();
		a3.name = "matt";
		a3.age = 40;
		String s3 = ser.createActor(a3);
		System.out.println(""+a3.name+" "+a3.age);
		System.out.println(s3);
		
		Actor a4 = new Actor();
		a4.name = "morgan";
		a4.age = 60;
		String s4 = ser.createActor(a4);
		System.out.println(""+a4.name+" "+a4.age);
		System.out.println(s4);
		
		
		
		
		ser.searchByName("leo");
		
		Repository r = new Repository();
		System.out.println(ser.a);
		
				
	}
}