public class Repository{
	
		public Actor arr[]=new Actor[4];
		int i = 0;
		int count = 0;
		
	
		boolean save(Actor a){
			arr[i] = a;
			i++;
			return true;
			}
			
			
		public Actor findByName(String name){
			for(int j=0; j<3;j++){
				if(arr[j].name== name){
					break;
				}
				count++;
			}
			return arr[count];
		}		
	
}
		
		
		
