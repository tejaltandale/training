public class Actor {
		String name;
		byte age;
}

 