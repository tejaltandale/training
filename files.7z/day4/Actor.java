public class Actor {
		private String name;
		private byte age;
		
		public void setName(String name){
			this.name=name;
		}
		
		public String getName(){
			return name;
		}
		
		public  void setAge(byte age){
			this.age=age;
		}
		
		public byte getAge(){
			return age;
		}
		
		public String toString(){
			return "\nFound "+name+"\nAge "+age;
		}
}

 