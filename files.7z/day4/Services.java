public class Services{
	Repository r = new Repository();
	
	public String createActor(Actor a){
		
				if(a.getName()!=null){
					r.save(a);
					return "Data Saved";
					
				}
		
				else {
					return "Name cannot be null";
								
			    }
	}
	
	Actor searchByName(String name){
		Actor a= r.findByName(name);
		return a;
		
	}
	
	Actor searchByAge(byte age){
		Actor ag= r.findByAge(age);
		return ag;
		
	}
}