public class Repository{
	
		public Actor arr[]=new Actor[5];
		static int i = 0;
		
		
	
		boolean save(Actor a){
			if(i<5){
			arr[i] = a;
			i++;
			return true;
			}
			else {
				arr = growArray(arr,i,a);
				return true;
			}
		}
			
		public Actor findByName(String name){
			for(int j=0; j<5;j++){
				if(arr[j].getName()== name){
					return arr[j];
				}
			}
			return null;
		}		
		
		public Actor findByAge(byte age){
			Actor arrAge[]=new Actor[5];
			for(int j=0; j<5;j++){
				if(arr[j].getAge()== age){
					
				arrAge[j]= arr[j];
				}
				return arrAge[j];
			}
			return null;
		}	
		
		
		public Actor[] growArray(Actor [] arr,int i,Actor a){
			Actor tempArr[] = new Actor[arr.length+1];
			int k;
			for(k=0;k<i;k++){
				tempArr[k]=arr[k];
			}
			tempArr[k]=a;
			return tempArr;
		}
		
		
	
}
		
		
		
