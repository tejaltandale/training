public class ActorClient{
	
	
	
	public static void main(String args[]){
		Services ser = new Services();
		
		Actor a1 = new Actor();
		a1.setName("leonardo");
		a1.setAge((byte)45);
		String s1 = ser.createActor(a1);
		System.out.println("\n"+a1.getName()+" "+a1.getAge());
		System.out.println(s1);
		
		Actor a2 = new Actor();
		a2.setName("johnny");
		a2.setAge((byte)40);
		String s2 = ser.createActor(a2);
		System.out.println("\n"+a2.getName()+" "+a2.getAge());
		System.out.println(s2);
		
		Actor a3 = new Actor();
		a3.setName("matt");
		a3.setAge((byte)40);
		String s3 = ser.createActor(a3);
		System.out.println("\n"+a3.getName()+" "+a3.getAge());
		System.out.println(s3);
		
		Actor a4 = new Actor();
		a4.setName("morgan");
		a4.setAge((byte)60);
		String s4 = ser.createActor(a4);
		System.out.println("\n"+a4.getName()+" "+a4.getAge());
		System.out.println(s4);
		
		Actor a5 = new Actor();
		a5.setName("keanu");
		a5.setAge((byte)50);
		String s5 = ser.createActor(a5);
		System.out.println("\n"+a5.getName()+" "+a5.getAge());
		System.out.println(s5);
		
		Actor a6 = new Actor();
		a6.setName("vin");
		a6.setAge((byte)55);
		String s6 = ser.createActor(a6);
		System.out.println("\n"+a6.getName()+" "+a6.getAge());
		System.out.println(s6);
		
		Actor a7 = new Actor();
		a7.setName("john");
		a7.setAge((byte)59);
		String s7 = ser.createActor(a7);
		System.out.println("\n"+a7.getName()+" "+a7.getAge());
		System.out.println(s7);
		
			
		System.out.println(ser.searchByName("leonardo"));
		System.out.println(ser.searchByAge((byte)50));
		

				
	}
}