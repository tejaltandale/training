public class DynamicArray{

public static void main(String args[]){

int[] smallArray ={1,2,3,4,5};
//smallArray= {1,2,3,4,5};

for(int i=0;i< 5;i++){
System.out.println(smallArray[i]);
}
//String[] temp = new String[6];
//System.arraycopy(smallArray, 0, temp, 0, smallArray.length);
//smallArray = temp;
}

}