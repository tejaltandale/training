/**
 * Created by jehaque on 07-Jun-16.
 */
var textArray = []

function  displayName() {

    var namesInput = document.getElementById("name")

    textArray.push(namesInput.value)
    loop:for (var i = 0; i < textArray.length; i++) {
        if (namesInput==textArray[i]) {
            alert("duplicates");
        } else {
            continue loop;
        }

    }



    namesInput.value =""
    namesInput.focus()
        var name = "["


    for (var i = 0; i < textArray.length; i++) {

           name  += textArray[i] + ","
        }

        document.getElementById("show").innerHTML = name + "]"
}

function sortAscending() {
    textArray.sort()
    var name = "["
    for (var i = 0; i < textArray.length; i++) {

        name  += textArray[i] + ","
    }

    document.getElementById("show").innerHTML = name + "]"
}

function sortDescending() {
    var name = "["
    textArray.reverse()
    for (var i = 0; i < textArray.length; i++) {

        name += textArray[i] + ","
    }

    document.getElementById("show").innerHTML = name + "]"
}

