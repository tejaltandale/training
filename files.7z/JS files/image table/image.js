/**
 * Created by jehaque on 08-Jun-16.
 */


function addImage() {


    var nameInput = document.getElementById("name").value;

    var urlInput = document.getElementById("url").value;

    var table = document.getElementById("myTable");

    var row = table.insertRow(0);
    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);

    cell1.innerHTML= nameInput;
    var img = new Image();
    img.src = urlInput;
    img.height = 100;
    img.width = 100;
    img.alt = "Image";

    cell2.appendChild(img);

    document.getElementById("name").value = "";
    document.getElementById("url").value = "";


}