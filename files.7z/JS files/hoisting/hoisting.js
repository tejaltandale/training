/**
 * Created by jehaque on 08-Jun-16.
 */

var a = b();
var c = d();
console.log(a);
console.log(c);

function b() {
    return c;
}

function d(){
    return b();
}
