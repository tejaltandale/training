/**
 * Created by jehaque on 09-Jun-16.
 */
function sendRequest() {
    var XHR = getXHR();
    if (XHR) {
        XHR.open("GET", "data.json", true);
        XHR.onreadystatechange = function () {
            handleResponse(XHR);
        }
        XHR.send();
    }
}

function getXHR() {
    return new XMLHttpRequest();
}

function handleResponse(XHR) {
    if (XHR.readyState == 4) {


        sideBar = document.getElementById('addData');

        persons = JSON.parse(XHR.responseText);

        sortAndDisplay();

    }
}
function getDetail(btn) {
    obj = btn;
    document.getElementById('firstName').value = persons[btn.id].firstName;

    document.getElementById('lastName').value = persons[btn.id].lastName;
    document.getElementById('city').value = persons[btn.id].city;

    document.getElementById('state').value = persons[btn.id].state;
}


function save() {

    persons[obj.id].firstName = document.getElementById('firstName').value;
    persons[obj.id].lastName = document.getElementById('lastName').value;
    persons[obj.id].city = document.getElementById('city').value;
    persons[obj.id].state = document.getElementById('state').value;
    //console.log(persons[obj.id].firstName);
    while (sideBar.rows.length > 0) {
        sideBar.deleteRow(0);
    }
    sortAndDisplay();


}

function sortAndDisplay() {
    document.getElementById('firstName').focus();
    arr = []
    for (var i = 0; i < persons.length; i++) {
        arr[i] = persons[i].firstName;

    }
    arr.sort();
    for (var i = 0; i < persons.length; i++) {
        for (var j = 0; j < persons.length; j++) {
            if (arr[i] == persons[j].firstName) {
                t = persons[i];
                persons[i] = persons[j];
                persons[j] = t;
            }

        }

    }
    for (var i = 0; i < persons.length; i++) {

        var row = sideBar.insertRow(i);
        row.id = i;
        var cell1 = row.insertCell(0);
        cell1.innerHTML = "<button type='button' class='btn btn-default btn-primary btn-block' onclick='getDetail(this)' id=" + i + ">" + persons[i].firstName + " " + persons[i].lastName + "</button>";
    }
}



